# Preference Adaptation Layer v5.2

Style decisions should respond to explicit user taste without becoming monotonous or overriding the photograph.

---

## 1. Preference types

Track only preferences that are explicit or repeatedly demonstrated in the current project.

### Hard reject
The user explicitly says a style is bad / unwanted.

Effect:
- remove that exact treatment from the candidate pool;
- record the failure reason;
- do not drift back toward the same visual signature through a renamed recipe.

### Strong like
The user explicitly identifies a treatment as a favorite.

Effect:
- add a modest preference bonus to compatible candidates;
- never force it onto incompatible photos;
- cap its batch frequency so the series does not become repetitive.

### Soft like
The user accepts a style or repeatedly chooses related outputs.

Effect:
- small tie-break bonus only.

---

## 2. Preference bonus

Apply preference **after** source-fit scoring.

Recommended adjustment:
- strong like: +4 to +8;
- soft like: +1 to +3;
- hard reject: remove candidate or apply a prohibitive penalty;
- explicitly requested style for a source: may override scoring unless it would destroy source identity.

User preference must not turn a weak 55-point source fit into an 85-point decision.

---

## 3. Saturation control

A favorite style is not a default template.

For a set of 6+ images:
- a strongly liked family may appear somewhat more often than neutral families;
- do not use it more than twice consecutively;
- vary layout signatures and transformation intensity;
- preserve at least two materially different visual languages when the sources support them.

---

## 4. Rejection memory

When the user rejects an output, record:
- source;
- family;
- layout signature;
- transformation level;
- rejection reason;
- whether the dislike concerns the **family**, **specific execution**, or **amount of transformation**.

Do not overgeneralize one bad execution into a ban on an entire family unless the user says so.

Example:
`I don't like this fourth style` may mean one concrete visual execution, not all minimal/graphic work. Diagnose before banning broadly.

---

## 5. Preference / fit arbitration

Tie-break order:
1. source preservation;
2. visual-behavior fit;
3. transformability;
4. explicit hard rejects;
5. user preference bonus;
6. batch diversity;
7. simplicity.

The photograph remains the primary authority.
