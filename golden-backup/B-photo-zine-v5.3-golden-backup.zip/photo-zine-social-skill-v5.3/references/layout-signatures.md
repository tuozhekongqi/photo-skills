# Layout Signatures v5.0

Style diversity is not enough; repeated composition can still make a set monotonous. Track layout signatures separately from style families.

## Core signatures

- `FULL_BLEED_QUIET` — full image, minimal or no text.
- `FULL_BLEED_CAPTION` — full image with one restrained caption block.
- `WHITE_FIELD_PLATE` — framed image on white / ivory field.
- `TOP_PHOTO_BOTTOM_PAPER` — photo above, conceptual/editorial paper space below.
- `TICKET_DIPTYCH` — photo + collectible ticket object.
- `APERTURE` — photo visible through one source-inspired paper aperture.
- `HERO_PLUS_MICROCROP` — one hero image plus 1-2 analytical crops from the same source.
- `CONTACT_SHEET_SINGLE_SOURCE` — multiple crops from one source only.
- `ASYMMETRIC_EDITORIAL` — image and text share an asymmetrical editorial grid.
- `EDGE_TRANSITION` — one source-derived transition from photo to print/paint.
- `CENTERED_SPECIMEN` — detail centered as an archival / collectible object.
- `GRAPHIC_FIELD` — one hero image/crop with 1-2 flat graphic planes.

## Repetition control

For 6 images:
- at least 3 layout signatures;
- no identical signature more than twice unless the user wants a formal series.

For 9 images:
- at least 4 signatures;
- avoid using `TOP_PHOTO_BOTTOM_PAPER` more than twice;
- avoid using `WHITE_FIELD_PLATE` more than twice;
- include at least one `FULL_BLEED_*` if a strong photo supports it.

## Layout selection rule

Choose layout after style family, not before. A style family may support multiple signatures. The source geometry decides which signature is appropriate.
