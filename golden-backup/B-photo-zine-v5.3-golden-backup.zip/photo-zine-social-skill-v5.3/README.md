# photo-zine-social v5.3

A source-first photo styling skill for turning real travel, landscape, architecture, street, city, garden, cultural-detail, and documentary photography into a coherent but varied social-media series.

## v5.1 focus: decision quality

The library is no longer driven mainly by subject labels. v5.1 adds a formal decision system that asks what the photo is **visually doing** before deciding how it should be treated.

### New in v5.3

- Prompt Compiler: converts decisions into structured source-led generation instructions.
- Copy Engine: derives titles / asides from the actual scene and allows no-text outputs.
- Retry & Recovery Policy: separates execution failure from bad style decisions and weak source selection.
- Source Selection Engine: culls both near-duplicate angles and redundant visual stories before styling.
- Preference Adaptation Layer: explicit likes/dislikes modify, but do not override, source fit.
- Series Planner: orders outputs by role, intensity, color, layout, and text rhythm.
- Visual Profile: focal strength, geometry, negative space, light, color, texture, narrative, motion, text tolerance, conceptual potential, and mood.
- 12 Visual Behavior Archetypes: an intermediate layer such as expansive negative space, directional depth, axial monumentality, reflective duality, ornamental radial structure, and motion network.
- Numeric Style Affinity Matrix: deterministic priors for candidate generation.
- T0-T3 Transformability: determines how much styling a source can tolerate.
- Weighted Candidate Scoring for the most plausible style families.
- Confidence Gate: weak style matches fall back to safer PRESERVE treatments.
- Primary + optional secondary influence, instead of vague multi-style blending.
- Batch Rebalancing: optimizes local fit + global rhythm.
- Style contraindication matrix for all 12 families.
- Decision counterexamples that prevent simplistic `subject -> style` routing.
- Layout signature tracking to prevent different styles from still looking compositionally repetitive.
- Evaluation protocol and redo diagnosis codes.
- Great Wall stress test demonstrating varied routing within one destination.

## 12 core style families

A. Travel Ticket / Souvenir Pass  
B. Watercolor Travel Editorial  
C. Minimal Collage Poster  
D. Second World Photo Editorial  
E. Soft Analog Diary  
F. Museum Catalogue  
G. Light & Negative-Space Poetry  
H. Cinematic Travel Still  
I. Modern Chinese Minimal  
J. Editorial Magazine Feature  
K. Monochrome Documentary  
L. Detail Collectible Card

## Core principle

> Understand the source first. Choose the lightest intervention that reveals what is already strong. Optimize each photo locally, then rebalance the set globally.

## Files

- `SKILL.md` — main operating instructions.
- `references/copy-engine.md` — copy modes and text-quality rules.
- `references/prompt-compiler.md` — structured generation prompt assembly.
- `references/retry-policy.md` — failure diagnosis and recovery.
- `references/source-selection-engine.md` — curation before style selection.
- `references/preference-adaptation.md` — bounded user-taste adaptation.
- `references/series-planner.md` — final sequence planning.
- `references/decision-engine.md` — visual profiling, archetypes, transformability, scoring, confidence, and rebalancing.
- `references/visual-archetypes.md` — behavior-first classification.
- `references/style-affinity-matrix.md` — numeric style priors.
- `references/style-fit-matrix.md` — when each family fits and when it should be rejected.
- `references/decision-counterexamples.md` — anti-pattern examples for better routing.
- `references/style-recipes.md` — detailed construction systems and sub-recipes.
- `references/prompt-library.md` — copy-ready generation, planning, and redo prompts.
- `references/batch-control.md` — source ledger, deduplication, continuation, and batch rules.
- `references/layout-signatures.md` — composition taxonomy and repetition control.
- `references/evaluation-protocol.md` — QA scoring and redo diagnosis.
- `references/research-notes.md` — design research notes.
- `examples/great-wall-stress-test.md` — decision pressure test for one destination.
- `examples/sample-decision-ledger.md` — compact planning example.
- `CHANGELOG.md` — version history.
