# Sample Decision Ledger v5.1

| idx | strongest_behavior | archetype | T | fidelity | primary(score) | secondary(score) | layout | role | status |
|---|---|---|---|---|---|---|---|---|---|
| 01 | directional cable into valley | V2+V10 | T3 | HYBRID | D(92) | H(85) | TOP_PHOTO_BOTTOM_PAPER | concept | pending |
| 02 | large sky over ridge | V1 | T0 | PRESERVE | G(95) | H(80) | FULL_BLEED_QUIET | breath | pending |
| 03 | centered carved medallion | V5+V12 | T2 | HYBRID | L(93) | F(88) | CENTERED_SPECIMEN | heritage_anchor | pending |
